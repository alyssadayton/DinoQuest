using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    private Rigidbody2D rigidBody;
    private Animator animator;
    private SpriteRenderer sprite;

    [Header("Stats")]
    [SerializeField] private float speed = 10;
    [SerializeField] private float jumpForce = 10;
    [SerializeField] private LayerMask jumpableGround;
    private float dirX;
    public float radius;
    public float damage;
    private bool grounded;
    private float jumpCooldown;
    public GameObject attackPoint; 
    public LayerMask enemies;

    
    [Header("Audio")]
    [SerializeField] private AudioSource jumpSound;
    [SerializeField] private AudioSource attackSound;
    [SerializeField] private AudioSource landedSound;



    // Start is called before the first frame update
    private void Start()
    {
        rigidBody = GetComponent<Rigidbody2D>();
        animator = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();
    }


    // Update is called once per frame
    private void Update()
    {
        UpdateAnimation();

        if (jumpCooldown > .1f)
        {
            rigidBody.velocity = new Vector2(dirX * speed, rigidBody.velocity.y);

            if (Input.GetKey(KeyCode.Space) && grounded) 
            {
                Jump();
            }
        }
        else
            jumpCooldown += Time.deltaTime;
            animator.SetTrigger("fall");

        if (Input.GetMouseButtonDown(0))
        {
            animator.SetBool("attack", true);
            attackSound.Play();
        }
    }

    private void Jump()
    {
            jumpSound.Play();
            rigidBody.velocity = new Vector2(rigidBody.velocity.x, jumpForce);
            grounded = false;
            animator.SetTrigger("jump");       
    }

    private void UpdateAnimation()
    {
        dirX = Input.GetAxisRaw("Horizontal");
        rigidBody.velocity = new Vector2(dirX * speed, rigidBody.velocity.y);

        // moving player left and right
        if (dirX > 0)
        {
            sprite.flipX = false;
        }
        else if (dirX < 0)
        {
            sprite.flipX = true;
        }
    
        animator.SetBool("run", dirX != 0);
        animator.SetBool("grounded", grounded);
    }

    public void attack()
    {
        Collider2D[] enemy = Physics2D.OverlapCircleAll(attackPoint.transform.position, radius, enemies);

        foreach (Collider2D enemyGameObject in enemy)
        {
            enemyGameObject.GetComponent<Health>().health -= damage;
        }
    }


    private void endAttack()
    {
        animator.SetBool("attack", false);
    }

    private void OnDrawGizmos()
    {
        Gizmos.DrawWireSphere(attackPoint.transform.position, radius);
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {     
        if (collision.gameObject.tag == "Ground")
        {
            landedSound.Play();
            grounded = true;
        }
    }
}

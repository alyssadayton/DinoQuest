using UnityEngine;

public class HealthCollectible : MonoBehaviour
{
    [SerializeField] private float healthValue;
    [SerializeField] private AudioSource collectSound;
    private Animator anim;

    private void Awake()
    {
        anim = GetComponent<Animator>();
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.tag == "Player")
        {
            collectSound.Play();
            anim.SetTrigger("collected");
            collision.GetComponent<Health>().AddHealth(healthValue);           
            gameObject.SetActive(false);            
        }
    }
}

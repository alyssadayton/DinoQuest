using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Health : MonoBehaviour
{
    [Header("Health")]
    [SerializeField] public float health;
    private Animator anim;
    private SpriteRenderer sprite;
    public float currentHealth { get; private set; }
    private bool dead;
    private float seconds;


    [Header("iFrames")]
    [SerializeField] private float iFramesDuration;
    [SerializeField] private float numberOfFlashes;
    [SerializeField] private AudioSource deathSound;
    [SerializeField] private AudioSource hitSound;
    

    private void Awake()
    {
        currentHealth = health;
        anim = GetComponent<Animator>();
        sprite = GetComponent<SpriteRenderer>();
    }

    public void TakeDamage(float _damage)
    {
        currentHealth = Mathf.Clamp(currentHealth - _damage, 0, health);

        if(currentHealth > 0)
        {
            anim.SetTrigger("hurt");
            hitSound.Play();
            StartCoroutine(Invunerability());
        }
        else
        {
            if (!dead)
            {
                anim.SetTrigger("die");
                GetComponent<PlayerMovement>().enabled = false;
                deathSound.Play();
                dead = true;
                seconds = Time.deltaTime;
            }           
            if (seconds == 5f)
            {
                RestartLevel();
            }
        }
    }

    public void AddHealth(float _value)
    {
        currentHealth = Mathf.Clamp(currentHealth + _value, 0, health);
    }

    public IEnumerator Invunerability()
    {
        Physics2D.IgnoreLayerCollision(10, 11, true);

        //invunerabity duration & Sprite color change
        for(int i = 0; i < numberOfFlashes; i++)
        {
            sprite.color = new Color(1, 0, 0, 0.5f);
            yield return new WaitForSeconds(iFramesDuration / (numberOfFlashes * 2));
            sprite.color = Color.white;
            yield return new WaitForSeconds(iFramesDuration / (numberOfFlashes * 2));
        }
        Physics2D.IgnoreLayerCollision(10, 11, true);
    }

    private void RestartLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}

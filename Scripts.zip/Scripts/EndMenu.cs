using UnityEngine;

public class EndMenu : MonoBehaviour
{
    public void QuitGame()
    {
        Application.Quit();
    }
}

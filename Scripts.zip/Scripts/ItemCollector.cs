using UnityEngine;
using UnityEngine.UI;

public class ItemCollector : MonoBehaviour
{
    [SerializeField] private Text coinsText;
    [SerializeField] private AudioSource coinsAudioSource;
    private int coinCount = 0;


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Coin"))
        {
            Destroy(collision.gameObject);
            coinsAudioSource.Play();
            coinCount++;
            coinsText.text = "Coin's: " + coinCount; 
        }
    }
}
